@extends('admin.layout')

@section('content')
	<h2>Error 404</h2>
@stop