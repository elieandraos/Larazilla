@extends('admin.layout')

@section('content')
	<h2>Permission Denied</h2>
@stop